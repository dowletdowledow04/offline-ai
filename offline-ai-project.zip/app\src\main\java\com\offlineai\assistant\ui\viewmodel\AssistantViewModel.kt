package com.offlineai.assistant.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.offlineai.assistant.data.model.ChatMessage
import com.offlineai.assistant.data.model.MessageSender
import com.offlineai.assistant.data.model.SystemPrompt
import com.offlineai.assistant.device.DeviceControllerRegistry
import com.offlineai.assistant.engine.LlmEngine
import com.offlineai.assistant.engine.MediaPipeLlmEngine
import com.offlineai.assistant.engine.MockLlmEngine
import com.offlineai.assistant.router.ActionDispatcher
import com.offlineai.assistant.router.ToolCallParser
import com.offlineai.assistant.voice.OfflineSttManager
import com.offlineai.assistant.voice.OfflineTtsManager
import com.offlineai.assistant.voice.SttState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class AssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(AssistantUiState())
    val uiState: StateFlow<AssistantUiState> = _uiState.asStateFlow()

    // Core Components
    private val toolCallParser = ToolCallParser()
    private val controllerRegistry = DeviceControllerRegistry(application)
    private val actionDispatcher = ActionDispatcher(toolCallParser, controllerRegistry)

    // Engines
    private val mockEngine = MockLlmEngine()
    private val mediaPipeEngine = MediaPipeLlmEngine(application)
    private var currentEngine: LlmEngine = mockEngine

    // Voice
    private val ttsManager = OfflineTtsManager(application)
    private val sttManager = OfflineSttManager(application)

    init {
        val welcomeMessage = ChatMessage(
            sender = MessageSender.ASSISTANT,
            text = "Salam! Men telefonyňyzdaky ähli işleri dolulygyna offline dolandyrýan emeli aň kömekçiňiz.\n\n🔦 Çyrany ýak / öçür\n📱 Programma aç\n📞 Jaň et\n🔊 Sesi sazla\n⏰ Budilnik goý\n🔋 Batareýa ýagdaýy\n\nGapdal ses düwmesine 2 gezek çalt basyp hem gürläp bilersiňiz!"
        )
        _uiState.update { it.copy(messages = listOf(welcomeMessage)) }

        viewModelScope.launch {
            sttManager.sttState.collect { state ->
                when (state) {
                    is SttState.Listening -> _uiState.update { it.copy(isListening = true) }
                    is SttState.Idle -> _uiState.update { it.copy(isListening = false) }
                    is SttState.Error -> _uiState.update {
                        it.copy(isListening = false, error = state.message)
                    }
                    is SttState.Success -> {
                        _uiState.update { it.copy(isListening = false) }
                        sendMessage(state.recognizedText)
                    }
                }
            }
        }
    }

    fun sendMessage(text: String) {
        val trimmed = text.trim()
        if (trimmed.isBlank() || _uiState.value.isGenerating) return

        val userMessage = ChatMessage(sender = MessageSender.USER, text = trimmed)
        _uiState.update {
            it.copy(
                messages = it.messages + userMessage,
                isGenerating = true,
                error = null
            )
        }

        viewModelScope.launch {
            try {
                val prompt = "${SystemPrompt.PROMPT}\n\nUlanyjy: $trimmed\nJogap:"
                val result = currentEngine.generate(prompt)

                if (result.isSuccess) {
                    val rawOutput = result.getOrThrow()
                    val toolAction = actionDispatcher.dispatch(rawOutput)

                    val responseText = when {
                        toolAction.response.isNotBlank() -> toolAction.response
                        toolAction.executionResult != null -> toolAction.executionResult!!
                        else -> "Buýruk ýerine ýetirildi."
                    }

                    // Append execution result to response if different
                    val fullText = if (
                        toolAction.executionResult != null &&
                        toolAction.executionResult != toolAction.response &&
                        toolAction.executionResult!!.isNotBlank()
                    ) {
                        "$responseText\n✅ ${toolAction.executionResult}"
                    } else {
                        responseText
                    }

                    val assistantMessage = ChatMessage(
                        sender = MessageSender.ASSISTANT,
                        text = fullText,
                        toolAction = toolAction
                    )

                    _uiState.update {
                        it.copy(messages = it.messages + assistantMessage, isGenerating = false)
                    }

                    ttsManager.speak(responseText)
                } else {
                    val errorMsg = result.exceptionOrNull()?.localizedMessage ?: "Jogap döretmekde näsazlyk"
                    _uiState.update { it.copy(isGenerating = false, error = errorMsg) }
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(isGenerating = false, error = e.localizedMessage ?: "Garaşylmadyk ýalňyşlyk")
                }
            }
        }
    }

    fun toggleVoiceRecognition() {
        if (_uiState.value.isListening) {
            sttManager.stopListening()
        } else {
            sttManager.startListening { recognizedText ->
                sendMessage(recognizedText)
            }
        }
    }

    fun loadMediaPipeModel(modelPath: String) {
        viewModelScope.launch {
            _uiState.update { it.copy(statusMessage = "MediaPipe modeli ýüklenýär...") }
            val res = mediaPipeEngine.initialize(modelPath)
            if (res.isSuccess) {
                currentEngine = mediaPipeEngine
                _uiState.update {
                    it.copy(
                        activeEngineName = mediaPipeEngine.name,
                        statusMessage = "MediaPipe modeli işjeň",
                        isModelLoaded = true
                    )
                }
            } else {
                _uiState.update {
                    it.copy(error = "Modeli ýükläp bolmady: ${res.exceptionOrNull()?.localizedMessage}")
                }
            }
        }
    }

    fun switchToSmartEngine() {
        currentEngine = mockEngine
        _uiState.update {
            it.copy(
                activeEngineName = mockEngine.name,
                statusMessage = "Türkmen AI Engine işjeň (Offline)",
                isModelLoaded = true
            )
        }
    }

    fun clearChat() {
        _uiState.update { it.copy(messages = emptyList(), error = null) }
    }

    override fun onCleared() {
        super.onCleared()
        ttsManager.shutdown()
        sttManager.stopListening()
        mediaPipeEngine.close()
    }
}
