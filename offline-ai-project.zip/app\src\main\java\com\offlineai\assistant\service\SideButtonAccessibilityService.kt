package com.offlineai.assistant.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.offlineai.assistant.MainActivity

/**
 * Intercepts physical side buttons (Volume Up / Down) system-wide.
 * Detects double-press within 500ms to launch or toggle the Offline AI Voice Assistant.
 */
class SideButtonAccessibilityService : AccessibilityService() {

    private var lastVolumeDownTime: Long = 0
    private var lastVolumeUpTime: Long = 0
    private val doubleClickThreshold = 500L // milliseconds

    override fun onKeyEvent(event: KeyEvent?): Boolean {
        if (event == null) return false

        val action = event.action
        val keyCode = event.keyCode

        // Detect on key down
        if (action == KeyEvent.ACTION_DOWN) {
            val currentTime = System.currentTimeMillis()

            when (keyCode) {
                KeyEvent.KEYCODE_VOLUME_DOWN -> {
                    if (currentTime - lastVolumeDownTime < doubleClickThreshold) {
                        // Double click detected on Volume Down!
                        triggerAssistantVoice()
                        lastVolumeDownTime = 0
                        return true // Consume key event
                    }
                    lastVolumeDownTime = currentTime
                }

                KeyEvent.KEYCODE_VOLUME_UP -> {
                    if (currentTime - lastVolumeUpTime < doubleClickThreshold) {
                        // Double click detected on Volume Up!
                        triggerAssistantVoice()
                        lastVolumeUpTime = 0
                        return true // Consume key event
                    }
                    lastVolumeUpTime = currentTime
                }
            }
        }

        // Allow normal volume changes for single clicks
        return super.onKeyEvent(event)
    }

    private fun triggerAssistantVoice() {
        // 1. Broadcast to running activity
        val broadcastIntent = Intent(ACTION_TRIGGER_ASSISTANT).apply {
            setPackage(packageName)
        }
        sendBroadcast(broadcastIntent)

        // 2. Also bring MainActivity to foreground if it is not open
        val activityIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
            putExtra(EXTRA_AUTO_START_VOICE, true)
        }
        startActivity(activityIntent)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    companion object {
        const val ACTION_TRIGGER_ASSISTANT = "com.offlineai.assistant.ACTION_TRIGGER_ASSISTANT"
        const val EXTRA_AUTO_START_VOICE = "EXTRA_AUTO_START_VOICE"
    }
}
