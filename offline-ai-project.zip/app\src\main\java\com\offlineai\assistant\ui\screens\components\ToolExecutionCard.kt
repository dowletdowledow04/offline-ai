package com.offlineai.assistant.ui.screens.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.offlineai.assistant.data.model.ExecutionStatus
import com.offlineai.assistant.data.model.ToolAction
import com.offlineai.assistant.ui.theme.AccentGreen
import com.offlineai.assistant.ui.theme.AccentRed
import com.offlineai.assistant.ui.theme.CardDarkElevated
import com.offlineai.assistant.ui.theme.PrimaryCyan

@Composable
fun ToolExecutionCard(
    toolAction: ToolAction,
    modifier: Modifier = Modifier
) {
    if (toolAction.action.equals("none", ignoreCase = true) || toolAction.action.isBlank()) {
        return
    }

    val (icon, label) = getToolIconAndLabel(toolAction.action)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(CardDarkElevated)
            .padding(10.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = icon,
                        contentDescription = label,
                        tint = PrimaryCyan,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = label,
                        color = Color.White,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Execution status indicator
                when (toolAction.executionStatus) {
                    ExecutionStatus.EXECUTING -> {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            strokeWidth = 2.dp,
                            color = PrimaryCyan
                        )
                    }
                    ExecutionStatus.SUCCESS -> {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Üstünlikli",
                            tint = AccentGreen,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    ExecutionStatus.FAILED -> {
                        Icon(
                            imageVector = Icons.Default.Error,
                            contentDescription = "Şowsuz",
                            tint = AccentRed,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    else -> Unit
                }
            }

            if (!toolAction.executionResult.isNullOrBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = toolAction.executionResult!!,
                    color = Color(0xFFCFD8DC),
                    fontSize = 12.sp
                )
            }
        }
    }
}

private fun getToolIconAndLabel(action: String): Pair<ImageVector, String> {
    return when (action.lowercase()) {
        "toggle_flashlight", "flashlight" -> Icons.Default.FlashlightOn to "Çyra dolandyryşy"
        "launch_app", "open_app" -> Icons.Default.Apps to "Programma açyş"
        "make_call", "call" -> Icons.Default.Call to "Telefon jaňy"
        "set_volume", "volume" -> Icons.Default.VolumeUp to "Ses sazlamasy"
        "set_alarm", "alarm" -> Icons.Default.Alarm to "Budilnik / Wagt"
        "get_system_info", "system_info" -> Icons.Default.Info to "Enjam ýagdaýy"
        else -> Icons.Default.Info to action
    }
}
