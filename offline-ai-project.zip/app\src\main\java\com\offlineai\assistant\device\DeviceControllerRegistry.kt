package com.offlineai.assistant.device

import android.content.Context
import com.offlineai.assistant.data.model.ActionResult

class DeviceControllerRegistry(context: Context) {

    private val flashlightController = FlashlightController(context)
    private val appLauncherController = AppLauncherController(context)
    private val telephonyController = TelephonyController(context)
    private val volumeBrightnessController = VolumeBrightnessController(context)
    private val alarmClockController = AlarmClockController(context)
    private val systemInfoController = SystemInfoController(context)

    suspend fun executeAction(action: String, parameters: Map<String, Any?>): ActionResult {
        return when (action.lowercase()) {
            "toggle_flashlight", "flashlight" -> flashlightController.execute(parameters)
            "launch_app", "open_app" -> appLauncherController.execute(parameters)
            "make_call", "call" -> telephonyController.execute(parameters)
            "send_sms", "sms" -> telephonyController.sendSms(parameters)
            "set_volume", "volume" -> volumeBrightnessController.execute(parameters)
            "set_alarm", "alarm" -> alarmClockController.execute(parameters)
            "get_system_info", "system_info", "battery" -> systemInfoController.execute(parameters)
            "none", "" -> ActionResult(true, "Ýönekeý jogap")
            else -> ActionResult(false, "Nämälim buýruk: $action")
        }
    }
}
