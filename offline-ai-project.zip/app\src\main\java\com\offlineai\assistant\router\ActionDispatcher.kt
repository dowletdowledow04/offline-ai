package com.offlineai.assistant.router

import com.offlineai.assistant.data.model.ExecutionStatus
import com.offlineai.assistant.data.model.ToolAction
import com.offlineai.assistant.device.DeviceControllerRegistry

class ActionDispatcher(
    private val toolCallParser: ToolCallParser,
    private val controllerRegistry: DeviceControllerRegistry
) {

    suspend fun dispatch(rawLlmOutput: String): ToolAction {
        val toolAction = toolCallParser.parse(rawLlmOutput)

        // If the action is none, return immediately without executing device APIs
        if (toolAction.action.equals("none", ignoreCase = true) || toolAction.action.isBlank()) {
            toolAction.executionStatus = ExecutionStatus.SKIPPED
            return toolAction
        }

        // Execute device hardware/system action
        toolAction.executionStatus = ExecutionStatus.EXECUTING
        val result = controllerRegistry.executeAction(toolAction.action, toolAction.parameters)

        if (result.success) {
            toolAction.executionStatus = ExecutionStatus.SUCCESS
            toolAction.executionResult = result.message
        } else {
            toolAction.executionStatus = ExecutionStatus.FAILED
            toolAction.executionResult = result.message
        }

        return toolAction
    }
}
