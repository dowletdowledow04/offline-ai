package com.offlineai.assistant.ui.viewmodel

import com.offlineai.assistant.data.model.ChatMessage

data class AssistantUiState(
    val messages: List<ChatMessage> = emptyList(),
    val isGenerating: Boolean = false,
    val isListening: Boolean = false,
    val activeEngineName: String = "Offline Smart Engine",
    val isModelLoaded: Boolean = true,
    val statusMessage: String = "Offline işe taýyn",
    val error: String? = null
)
