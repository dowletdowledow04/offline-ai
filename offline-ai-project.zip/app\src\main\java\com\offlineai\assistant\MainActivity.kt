package com.offlineai.assistant

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.offlineai.assistant.service.SideButtonAccessibilityService
import com.offlineai.assistant.ui.screens.MainAssistantScreen
import com.offlineai.assistant.ui.theme.AndroidOfflineAITheme
import com.offlineai.assistant.ui.theme.DarkBackground
import com.offlineai.assistant.ui.viewmodel.AssistantViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: AssistantViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    // Receiver for side button events from Background Accessibility Service
    private val assistantTriggerReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            viewModel.toggleVoiceRecognition()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Request initial hardware permissions
        requestDevicePermissions()

        // Handle auto-start voice if launched by side button
        handleIntentExtra(intent)

        // Register receiver for background side button trigger
        val filter = IntentFilter(SideButtonAccessibilityService.ACTION_TRIGGER_ASSISTANT)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(assistantTriggerReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(assistantTriggerReceiver, filter)
        }

        setContent {
            AndroidOfflineAITheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkBackground
                ) {
                    MainAssistantScreen(
                        viewModel = viewModel,
                        onRequestPermissions = { requestDevicePermissions() },
                        onOpenAccessibilitySettings = { openAccessibilitySettings() }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntentExtra(intent)
    }

    private fun handleIntentExtra(intent: Intent?) {
        if (intent?.getBooleanExtra(SideButtonAccessibilityService.EXTRA_AUTO_START_VOICE, false) == true) {
            viewModel.toggleVoiceRecognition()
        }
    }

    /**
     * Intercept physical hardware volume keys (bakawoý knopkalar)
     * when the application is open on screen.
     */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            // Physical side button pressed: toggle voice assistant
            viewModel.toggleVoiceRecognition()
            return true // Consume to prevent volume slider if desired
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(intent)
    }

    private fun requestDevicePermissions() {
        permissionLauncher.launch(
            arrayOf(
                Manifest.permission.RECORD_AUDIO,
                Manifest.permission.CAMERA,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.SEND_SMS
            )
        )
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            unregisterReceiver(assistantTriggerReceiver)
        } catch (_: Exception) {}
    }
}
