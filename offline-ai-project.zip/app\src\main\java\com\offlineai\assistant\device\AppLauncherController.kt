package com.offlineai.assistant.device

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.MediaStore
import android.provider.Settings
import com.offlineai.assistant.data.model.ActionResult

class AppLauncherController(private val context: Context) : DeviceController {

    override val actionName: String = "launch_app"

    override suspend fun execute(parameters: Map<String, Any?>): ActionResult {
        val appQuery = parameters["app_name"]?.toString()?.trim()?.lowercase()
            ?: return ActionResult(false, "Programmanyň ady görkezilmedi")

        // 1. Direct system intent matches
        when {
            appQuery.contains("kamera") || appQuery.contains("camera") -> {
                val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return ActionResult(true, "Kamera açyldy")
            }

            appQuery.contains("sazlama") || appQuery.contains("settings") -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return ActionResult(true, "Sazlamalar açyldy")
            }

            appQuery.contains("wi-fi") || appQuery.contains("wifi") -> {
                val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return ActionResult(true, "Wi-Fi sazlamalary açyldy")
            }

            appQuery.contains("bluetooth") -> {
                val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return ActionResult(true, "Bluetooth sazlamalary açyldy")
            }
        }

        // 2. Search installed applications by label or package name
        val packageManager = context.packageManager
        val installedApps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)

        for (appInfo in installedApps) {
            val appLabel = packageManager.getApplicationLabel(appInfo).toString().lowercase()
            val packageName = appInfo.packageName.lowercase()

            if (appLabel.contains(appQuery) || packageName.contains(appQuery)) {
                val launchIntent = packageManager.getLaunchIntentForPackage(appInfo.packageName)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(launchIntent)
                    return ActionResult(true, "$appLabel açyldy", mapOf("package" to appInfo.packageName))
                }
            }
        }

        return ActionResult(false, "'$appQuery' atly programma tapylmady")
    }
}
