package com.offlineai.assistant.device

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.offlineai.assistant.data.model.ActionResult

class TelephonyController(private val context: Context) : DeviceController {

    override val actionName: String = "make_call"

    override suspend fun execute(parameters: Map<String, Any?>): ActionResult {
        val phoneNumber = parameters["phone_number"]?.toString()?.trim()
            ?: return ActionResult(false, "Telefon belgisi görkezilmedi")

        return try {
            // Use ACTION_DIAL so it doesn't strictly crash if CALL_PHONE runtime permission isn't granted yet
            val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                data = Uri.parse("tel:$phoneNumber")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(dialIntent)
            ActionResult(true, "$phoneNumber belgisine jaň edilýär", mapOf("phone" to phoneNumber))
        } catch (e: Exception) {
            ActionResult(false, "Jaň etmekde säwlik: ${e.localizedMessage}")
        }
    }

    suspend fun sendSms(parameters: Map<String, Any?>): ActionResult {
        val phoneNumber = parameters["phone_number"]?.toString()?.trim() ?: ""
        val message = parameters["message"]?.toString()?.trim() ?: ""

        return try {
            val smsIntent = Intent(Intent.ACTION_SENDTO).apply {
                data = Uri.parse("smsto:$phoneNumber")
                putExtra("sms_body", message)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(smsIntent)
            ActionResult(true, "SMS ugratmak üçin hat taýýarlandy", mapOf("phone" to phoneNumber, "body" to message))
        } catch (e: Exception) {
            ActionResult(false, "SMS taýýarlamakda säwlik: ${e.localizedMessage}")
        }
    }
}
