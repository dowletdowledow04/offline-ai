package com.offlineai.assistant

import android.app.Application

class OfflineAiApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
