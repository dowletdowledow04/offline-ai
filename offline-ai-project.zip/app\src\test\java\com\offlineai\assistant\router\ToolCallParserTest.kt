package com.offlineai.assistant.router

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

class ToolCallParserTest {

    private lateinit var parser: ToolCallParser

    @Before
    fun setUp() {
        parser = ToolCallParser()
    }

    @Test
    fun testParseStandardJson() {
        val rawLlm = """
        {
          "thought": "Ulanyjy çyrany ýakmagy buýurdy",
          "action": "toggle_flashlight",
          "parameters": {
            "enabled": true
          },
          "response": "Bolýar, çyrany ýakdym!"
        }
        """.trimIndent()

        val action = parser.parse(rawLlm)
        assertEquals("toggle_flashlight", action.action)
        assertEquals(true, action.parameters["enabled"])
        assertEquals("Bolýar, çyrany ýakdym!", action.response)
    }

    @Test
    fun testParseMarkdownFencedJson() {
        val rawLlm = """
        Elbetde, buýrugy ýerine ýetirýärin:
        ```json
        {
          "thought": "YouTube açylmaly",
          "action": "launch_app",
          "parameters": {
            "app_name": "youtube"
          },
          "response": "YouTube açylýar..."
        }
        ```
        """.trimIndent()

        val action = parser.parse(rawLlm)
        assertEquals("launch_app", action.action)
        assertEquals("youtube", action.parameters["app_name"])
        assertEquals("YouTube açylýar...", action.response)
    }

    @Test
    fun testParseAlarmAction() {
        val rawLlm = """
        {
          "thought": "Sagat 07:30-a budilnik",
          "action": "set_alarm",
          "parameters": {
            "hour": 7,
            "minute": 30,
            "message": "Oýanmak"
          },
          "response": "Budilnik guruldy"
        }
        """.trimIndent()

        val action = parser.parse(rawLlm)
        assertEquals("set_alarm", action.action)
        // Gson parses numbers in maps as Double by default unless strongly typed
        val hour = (action.parameters["hour"] as Number).toInt()
        val minute = (action.parameters["minute"] as Number).toInt()
        assertEquals(7, hour)
        assertEquals(30, minute)
    }

    @Test
    fun testFallbackForPlainText() {
        val plainText = "Salam! Men telefonyňyzdaky ähli işleri offline dolandyrýan kömekçi."
        val action = parser.parse(plainText)

        assertEquals("none", action.action)
        assertEquals(plainText, action.response)
        assertTrue(action.parameters.isEmpty())
    }
}
