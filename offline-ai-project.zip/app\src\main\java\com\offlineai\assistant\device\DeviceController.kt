package com.offlineai.assistant.device

import com.offlineai.assistant.data.model.ActionResult

/**
 * Base interface for all Android system and hardware controllers.
 */
interface DeviceController {
    val actionName: String
    suspend fun execute(parameters: Map<String, Any?>): ActionResult
}
