package com.offlineai.assistant.engine

import android.content.Context
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * MediaPipe LLM Inference Engine stub.
 * Full integration requires: implementation(libs.mediapipe.tasks.genai) in build.gradle
 * and a Gemma 2B / Gemini Nano .task model file placed on the device.
 *
 * By default this is disabled and the app uses MockLlmEngine (TurkmenNlpEngine) which
 * understands all Turkmen voice/text commands fully offline without any model file.
 */
class MediaPipeLlmEngine(private val context: Context) : LlmEngine {

    override val name: String = "MediaPipe (Gemma 2B / Gemini Nano) [TAÝÝAR DEL - Model gerek]"
    override val isReady: Boolean = false

    override suspend fun initialize(modelPath: String): Result<Unit> {
        return Result.failure(
            UnsupportedOperationException(
                "MediaPipe motory häzirki wagtda işjeň däl. " +
                "Ulanmak üçin: 1) build.gradle-da mediapipe.tasks.genai kommentardan çykaryň, " +
                "2) Gemma 2B .task faýlyny /data/local/tmp/ bukjasyna geçiriň."
            )
        )
    }

    override suspend fun generate(prompt: String): Result<String> {
        return Result.failure(IllegalStateException("MediaPipe motory işjeň däl. Smart Engine ulanylýar."))
    }

    override fun generateStream(prompt: String): Flow<String> = flow {
        throw IllegalStateException("MediaPipe motory işjeň däl.")
    }

    override fun close() {}
}
