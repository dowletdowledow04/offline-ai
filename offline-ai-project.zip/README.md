# Offline Android AI Kömekçisi 🚀

Bu programma Android enjamynda **dolulygyna internetsiz (offline)** işleýän, emeli aň arkaly ulanyjynyň sesli we ýazmaça buýruklaryna düşünýän hem-de telefonyň enjam funksiýalaryny dolandyrýan şahsy kömekçidir.

---

## 📱 Esasy Funksiýalary

- **🔦 Çyra (Flashlight)**: Çyrany açmak / öçürmek ("Çyrany ýak", "Çyrany öçür").
- **📱 Programmalary Açmak**: Islendik programmany açmak ("YouTube aç", "Telegramy aç", "Kamerany aç", "Sazlamalary aç").
- **📞 Jaň we SMS**: Telefon belgisine göni jaň etmek ýa-da SMS taýýarlamak ("+99365... belgä jaň et").
- **🔊 Ses Derejesi**: Telefonyň sesini sazlamak ("Telefonyň sesini 70% et").
- **⏰ Budilnik we Wagt**: Islän wagtyňyza budilnik gurmak ("Ertir sagat 07:30 üçin budilnik goý").
- **🔋 Enjam Ýagdaýy**: Batareýa zarýadyny, Wi-Fi we boş ýat göwrümini barlamak ("Batareýam näçe göterim galdy?").
- **🎙️ Offline Ses (STT & TTS)**: Internetsiz ses tanama we jogaplary sesli okap bermek.
- **💬 Gürrüňdeşlik**: Soraglara tebigy dilde jogap bermek.

---

## 🧠 Model we Arhitektura

Taslama 3 sany motory goldaýar:

1. **Smart Simulated Engine (Deslapky)**:
   - Gurlan badyna hiç hili model faýly (2GB) göçürmän hem ähli Android funksiýalaryny we türkmen dilindäki buýruklary derrew barlamaga mümkinçilik berýär.
2. **Google MediaPipe LLM Inference (Gemma 2 2B / Gemini Nano)**:
   - Google-yň resmi çelgisi. `.task` formatyndaky modeli göni GPU/NPU arkaly çalt işleter.
3. **llama.cpp (GGUF)**:
   - Qwen 2.5 (0.5B / 1.5B) we Llama 3.2 (1B) modellerini iň az RAM sarp edip işletmek üçin niýetlenen.

---

## 📂 Taslamanyň Gurluşy

```
android-offline-ai/
├── app/
│   ├── src/main/java/com/offlineai/assistant/
│   │   ├── MainActivity.kt               # Esasy Activity & rugsatlar
│   │   ├── OfflineAiApp.kt               # Application klasy
│   │   ├── data/model/
│   │   │   ├── ChatMessage.kt            # Hat modeli
│   │   │   ├── ToolAction.kt             # JSON Tool Calling formaty
│   │   │   └── SystemPrompt.kt           # LLM üçin ulgam kadasy (Türkmençe)
│   │   ├── device/                       # Android enjam dolandyryjylary
│   │   │   ├── FlashlightController.kt   # Çyra
│   │   │   ├── AppLauncherController.kt  # Programma açyş
│   │   │   ├── TelephonyController.kt    # Jaň we SMS
│   │   │   ├── VolumeBrightnessController.kt # Ses sazlamasy
│   │   │   ├── AlarmClockController.kt   # Budilnik
│   │   │   ├── SystemInfoController.kt   # Batareýa & ulgam maglumaty
│   │   │   └── DeviceControllerRegistry.kt # Registry
│   │   ├── engine/                       # LLM Inferences
│   │   │   ├── LlmEngine.kt              # Umumy interfeýs
│   │   │   ├── MediaPipeLlmEngine.kt     # Google Gemma 2B engine
│   │   │   ├── MockLlmEngine.kt          # Smart local test engine
│   │   │   └── LlamaCppEngine.kt         # llama.cpp GGUF bridge
│   │   ├── router/
│   │   │   ├── ToolCallParser.kt         # JSON pars ediji
│   │   │   └── ActionDispatcher.kt       # Buýruklary ýerine ýetiriji
│   │   ├── voice/
│   │   │   ├── OfflineTtsManager.kt      # Offline TextToSpeech
│   │   │   └── OfflineSttManager.kt      # Offline SpeechRecognizer
│   │   └── ui/                           # Jetpack Compose interfeýsi
│   │       ├── screens/MainAssistantScreen.kt
│   │       ├── screens/ModelSettingsDialog.kt
│   │       └── viewmodel/AssistantViewModel.kt
```

---

## 🛠️ Nädip Işletmeli?

1. **Android Studio-da Açyň**:
   - Android Studio-ny açyň we **Open Project** basyp şu bukjany saýlaň:
     `C:\Users\User\.gemini\antigravity\scratch\android-offline-ai`
2. **Sync & Run**:
   - Gradle sinhronizasiýasy awtomatiki geçer.
   - Telefonyňyzy (USB Debugging açyk) ýa-da Emulýatory birikdirip, **Run (Shift + F10)** basyň.
3. **Gemma 2B Modeli Goşmak (Isläniňizde)**:
   - Kaggle ýa-da HuggingFace-den `gemma-2b-it-gpu-int4.task` faýlyny göçürip alyň.
   - `adb push gemma-2b-it-gpu-int4.task /data/local/tmp/` buýrugy bilen telefona geçiriň.
   - Programmada sag ýokardaky ⚙️ **Sazlamalar** düwmesine basyp, model faýlynyň ýoluny giriziň.
