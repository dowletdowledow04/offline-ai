package com.offlineai.assistant.engine

import com.google.gson.Gson
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow

/**
 * Intelligent on-device engine powered by TurkmenNlpEngine.
 * Understands natural spoken and written Turkmen commands with phonetic tolerance.
 * Emits robust JSON tool calls directly compatible with ActionDispatcher and Device Controllers.
 */
class MockLlmEngine(private val gson: Gson = Gson()) : LlmEngine {

    override val name: String = "Offline Smart Engine (Türkmençe & Enjam Dolandyryş)"
    override val isReady: Boolean = true

    override suspend fun initialize(modelPath: String): Result<Unit> = Result.success(Unit)

    override suspend fun generate(prompt: String): Result<String> {
        delay(200) // Fast offline response
        val userQuery = prompt.substringAfterLast("Ulanyjy:").substringBefore("\nJogap:").trim()
        val toolAction = TurkmenNlpEngine.processTurkmenCommand(userQuery)
        val jsonOutput = gson.toJson(toolAction)
        return Result.success(jsonOutput)
    }

    override fun generateStream(prompt: String): Flow<String> = flow {
        val res = generate(prompt)
        val full = res.getOrDefault("")
        for (chunk in full.chunked(16)) {
            delay(30)
            emit(chunk)
        }
    }

    override fun close() {}
}
