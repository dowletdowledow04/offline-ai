@echo off
setlocal enabledelayedexpansion
echo.
echo ============================================================
echo  Offline AI Komekci - SDK Gurnamak + APK Dörediş Skripti
echo ============================================================
echo.

set "SDK_DIR=C:\android-sdk"
set "SDK_ZIP=%SDK_DIR%\cmdline-tools.zip"
set "TOOLS_DIR=%SDK_DIR%\cmdline-tools\latest"

REM ---- 1. Java check ----
java -version >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [YALNYSHLYK] Java tapylmady! Java 17+ gurunyzynyz barlap gorung.
    pause & exit /b 1
)
echo [OK] Java bar.

REM ---- 2. Check SDK cmdline-tools ----
if exist "%TOOLS_DIR%\bin\sdkmanager.bat" (
    echo [OK] Android SDK cmdline-tools bar.
    goto :install_sdk_packages
)

REM ---- 3. Unzip cmdline-tools ----
if not exist "%SDK_ZIP%" (
    echo [YALNYSHLYK] SDK zip fayli tapylmady: %SDK_ZIP%
    echo Ony yuklemek ucin oz-ozunden gidiyor... (bu skript tarapyndan eltilyar)
    pause & exit /b 1
)
echo [>>] SDK cmdline-tools gurnalýar...
powershell -Command "Expand-Archive -Path '%SDK_ZIP%' -DestinationPath '%SDK_DIR%\cmdline-tools-tmp' -Force"
if not exist "%SDK_DIR%\cmdline-tools-tmp\cmdline-tools" (
    echo [YALNYSHLYK] ZIP acylmady.
    pause & exit /b 1
)
if not exist "%TOOLS_DIR%" mkdir "%TOOLS_DIR%"
xcopy /E /I /Y "%SDK_DIR%\cmdline-tools-tmp\cmdline-tools\*" "%TOOLS_DIR%\" >nul
rmdir /S /Q "%SDK_DIR%\cmdline-tools-tmp"
echo [OK] cmdline-tools gurnaldy.

:install_sdk_packages
REM ---- 4. Accept licenses + install build-tools + platform ----
set "SDKMANAGER=%TOOLS_DIR%\bin\sdkmanager.bat"
echo [>>] Rugsat berilyan...
echo y | call "%SDKMANAGER%" --sdk_root="%SDK_DIR%" --licenses >nul 2>&1
echo [>>] Android 34 we Build-Tools 34 gurunylyor...
call "%SDKMANAGER%" --sdk_root="%SDK_DIR%" "platforms;android-34" "build-tools;34.0.0" "platform-tools"
if %ERRORLEVEL% neq 0 (
    echo [YALNYSHLYK] SDK paketikaryny yukläp bolmady.
    pause & exit /b 1
)
echo [OK] SDK paketleri tayyar.

REM ---- 5. Build APK ----
echo.
echo [>>] APK doresdirilyor...
echo sdk.dir=C\:\\android-sdk> local.properties
call gradlew.bat assembleDebug --no-daemon

if %ERRORLEVEL% equ 0 (
    echo.
    echo ============================================================
    echo  [USTUNLIKLI] APK tayyar boldy!
    echo  Fayl yoly: app\build\outputs\apk\debug\app-debug.apk
    echo.
    echo  Bu APK-ny telefonynyza geciryar (Telegram, kabel, USB):
    echo  Telefonynyzda 'Naymallar cesmelerden gurmage rugsat ber'
    echo  sazyamasyny acyng we APK ustune basynyz!
    echo ============================================================
    explorer app\build\outputs\apk\debug\
) else (
    echo.
    echo [YALNYSHLYK] APK doresip bolmady. Yalgys goren ucin ykarky cykyshy goryng.
)
echo.
pause
