package com.offlineai.assistant.device

import android.content.Context
import android.hardware.camera2.CameraManager
import com.offlineai.assistant.data.model.ActionResult

class FlashlightController(private val context: Context) : DeviceController {

    override val actionName: String = "toggle_flashlight"

    private var isTorchOn = false

    override suspend fun execute(parameters: Map<String, Any?>): ActionResult {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
                ?: return ActionResult(false, "Kamera gurluşy tapylmady")

            val cameraId = cameraManager.cameraIdList.firstOrNull()
                ?: return ActionResult(false, "Çyra gurluşy tapylmady")

            // Determine target state
            val desiredState = when (val enabled = parameters["enabled"]) {
                is Boolean -> enabled
                is String -> enabled.equals("true", ignoreCase = true) || enabled.equals("on", ignoreCase = true)
                else -> !isTorchOn // Toggle if unspecified
            }

            cameraManager.setTorchMode(cameraId, desiredState)
            isTorchOn = desiredState

            val statusMsg = if (desiredState) "Çyra ýakyldy" else "Çyra öçürildi"
            ActionResult(true, statusMsg, mapOf("torch_on" to desiredState))
        } catch (e: Exception) {
            ActionResult(false, "Çyrany dolandyrmakda säwlik: ${e.localizedMessage}")
        }
    }
}
