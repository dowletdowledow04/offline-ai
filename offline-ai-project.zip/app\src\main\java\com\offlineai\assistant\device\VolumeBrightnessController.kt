package com.offlineai.assistant.device

import android.content.Context
import android.media.AudioManager
import com.offlineai.assistant.data.model.ActionResult

class VolumeBrightnessController(private val context: Context) : DeviceController {

    override val actionName: String = "set_volume"

    override suspend fun execute(parameters: Map<String, Any?>): ActionResult {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            ?: return ActionResult(false, "Ses ulgamy tapylmady")

        val levelPercent = when (val lvl = parameters["level"]) {
            is Number -> lvl.toInt().coerceIn(0, 100)
            is String -> lvl.toIntOrNull()?.coerceIn(0, 100) ?: 50
            else -> 50
        }

        val streamType = when (parameters["stream"]?.toString()?.lowercase()) {
            "ring" -> AudioManager.STREAM_RING
            "alarm" -> AudioManager.STREAM_ALARM
            else -> AudioManager.STREAM_MUSIC
        }

        val maxVolume = audioManager.getStreamMaxVolume(streamType)
        val targetIndex = (maxVolume * (levelPercent / 100f)).toInt().coerceIn(0, maxVolume)

        audioManager.setStreamVolume(streamType, targetIndex, AudioManager.FLAG_SHOW_UI)

        return ActionResult(
            success = true,
            message = "Ses derejesi $levelPercent% edildi",
            data = mapOf("percent" to levelPercent, "index" to targetIndex)
        )
    }
}
