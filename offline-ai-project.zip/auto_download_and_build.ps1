$ErrorActionPreference = "Continue"
$sdkDir = "C:\android-sdk"
$zipPath = "$sdkDir\cmdline-tools.zip"
$toolsDir = "$sdkDir\cmdline-tools\latest"
$url = "https://dl.google.com/android/repository/commandlinetools-win-11076708_latest.zip"

Write-Host ">>> 1. Android SDK cmdline-tools yuklenyär (Resume goldawy bilen)..."
if (-not (Test-Path $sdkDir)) { New-Item -ItemType Directory -Path $sdkDir -Force | Out-Null }

# Loop curl until complete (handles drops and timeouts)
$attempts = 0
while ($attempts -lt 25) {
    $attempts++
    Write-Host "Download synanyshy: $attempts..."
    & curl.exe -L -C - -o $zipPath $url --max-time 120 --retry 3
    
    # Check if download is complete (~147MB = ~147500000 bytes)
    if (Test-Path $zipPath) {
        $size = (Get-Item $zipPath).Length
        Write-Host "Hazirki gowrum: $size bayt"
        if ($size -ge 147000000) {
            Write-Host ">>> SDK Zip doly yuklendi!"
            break
        }
    }
    Start-Sleep -Seconds 2
}

# 2. Extract
Write-Host ">>> 2. Arhiw acylyar..."
$tempExtract = "$sdkDir\tmp_cmdline"
if (Test-Path $tempExtract) { Remove-Item $tempExtract -Recurse -Force }
Expand-Archive -Path $zipPath -DestinationPath $tempExtract -Force

if (-not (Test-Path $toolsDir)) { New-Item -ItemType Directory -Path $toolsDir -Force | Out-Null }
Copy-Item "$tempExtract\cmdline-tools\*" -Destination $toolsDir -Recurse -Force
Remove-Item $tempExtract -Recurse -Force
Write-Host ">>> cmdline-tools gurnaldy!"

# 3. Install packages
Write-Host ">>> 3. Android 34 Platform we Build-Tools gurnalýar..."
$sdkmanager = "$toolsDir\bin\sdkmanager.bat"
$yes = "y`ny`ny`ny`ny`n"
$yes | & $sdkmanager --sdk_root=$sdkDir --licenses
& $sdkmanager --sdk_root=$sdkDir "platforms;android-34" "build-tools;34.0.0" "platform-tools"

# 4. Build APK
Write-Host ">>> 4. APK yygnanyar (Gradle assembleDebug)..."
Set-Location "C:\Users\User\.gemini\antigravity\scratch\android-offline-ai"
"sdk.dir=C\:\\android-sdk" | Out-File -FilePath "local.properties" -Encoding ascii
& .\gradlew.bat assembleDebug --no-daemon

$apk = "app\build\outputs\apk\debug\app-debug.apk"
if (Test-Path $apk) {
    Write-Host "========================================================="
    Write-Host ">>> USTUNLIKLI! APK TAYYAR BOLDY: $apk"
    Write-Host "========================================================="
    Copy-Item $apk "C:\Users\User\Desktop\OfflineAI_Komekci.apk" -Force -ErrorAction SilentlyContinue
} else {
    Write-Host ">>> Yalnyshlyk boldy."
}
