package com.offlineai.assistant.engine

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Test

class TurkmenNlpEngineTest {

    @Test
    fun testFlashlightCommands() {
        val onAction = TurkmenNlpEngine.processTurkmenCommand("çyrany ýak")
        assertEquals("toggle_flashlight", onAction.action)
        assertEquals(true, onAction.parameters["enabled"])

        val offAction = TurkmenNlpEngine.processTurkmenCommand("fonarigi öçür")
        assertEquals("toggle_flashlight", offAction.action)
        assertEquals(false, offAction.parameters["enabled"])

        // Phonetic variation test
        val phoneticOn = TurkmenNlpEngine.processTurkmenCommand("cirany yak")
        assertEquals("toggle_flashlight", phoneticOn.action)
        assertEquals(true, phoneticOn.parameters["enabled"])
    }

    @Test
    fun testLaunchAppCommands() {
        val yt = TurkmenNlpEngine.processTurkmenCommand("ýutuby aç")
        assertEquals("launch_app", yt.action)
        assertEquals("youtube", yt.parameters["app_name"])

        val tg = TurkmenNlpEngine.processTurkmenCommand("telegram aç")
        assertEquals("launch_app", tg.action)
        assertEquals("telegram", tg.parameters["app_name"])

        val cam = TurkmenNlpEngine.processTurkmenCommand("kamera aç")
        assertEquals("launch_app", cam.action)
        assertEquals("kamera", cam.parameters["app_name"])
    }

    @Test
    fun testVolumeCommands() {
        val vol = TurkmenNlpEngine.processTurkmenCommand("sesini 80% et")
        assertEquals("set_volume", vol.action)
        assertEquals(80, vol.parameters["level"])

        val mute = TurkmenNlpEngine.processTurkmenCommand("sesi öçür")
        assertEquals("set_volume", mute.action)
        assertEquals(0, mute.parameters["level"])
    }

    @Test
    fun testAlarmCommands() {
        val alarm = TurkmenNlpEngine.processTurkmenCommand("ertir sagat 07:30 üçin budilnik goý")
        assertEquals("set_alarm", alarm.action)
        assertEquals(7, alarm.parameters["hour"])
        assertEquals(30, alarm.parameters["minute"])
    }

    @Test
    fun testBatteryAndSystemInfo() {
        val battery = TurkmenNlpEngine.processTurkmenCommand("zarýad näçe galdy?")
        assertEquals("get_system_info", battery.action)
        assertEquals("battery", battery.parameters["query"])

        val wifi = TurkmenNlpEngine.processTurkmenCommand("wi-fi barmy?")
        assertEquals("get_system_info", wifi.action)
        assertEquals("wifi", wifi.parameters["query"])
    }

    @Test
    fun testCallCommand() {
        val call = TurkmenNlpEngine.processTurkmenCommand("+99365123456 belgä jaň et")
        assertEquals("make_call", call.action)
        assertEquals("+99365123456", call.parameters["phone_number"])
    }

    @Test
    fun testConversationalTurkmen() {
        val greeting = TurkmenNlpEngine.processTurkmenCommand("Salam, ýagdaýlar nähili?")
        assertEquals("none", greeting.action)
        assertNotNull(greeting.response)
    }
}
