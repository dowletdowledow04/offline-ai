package com.offlineai.assistant.engine

import kotlinx.coroutines.flow.Flow

interface LlmEngine {
    val name: String
    val isReady: Boolean
    suspend fun initialize(modelPath: String): Result<Unit>
    suspend fun generate(prompt: String): Result<String>
    fun generateStream(prompt: String): Flow<String>
    fun close()
}
