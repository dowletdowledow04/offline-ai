package com.offlineai.assistant.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF0F1117)
val CardDark = Color(0xFF1B1E2B)
val CardDarkElevated = Color(0xFF252A3D)
val PrimaryCyan = Color(0xFF00E5FF)
val PrimaryCyanDark = Color(0xFF00B0FF)
val AccentGreen = Color(0xFF00E676)
val AccentOrange = Color(0xFFFF9100)
val AccentRed = Color(0xFFFF5252)
val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF9BA3AF)
val UserBubbleColor = Color(0xFF2962FF)
val AssistantBubbleColor = Color(0xFF1E2438)
