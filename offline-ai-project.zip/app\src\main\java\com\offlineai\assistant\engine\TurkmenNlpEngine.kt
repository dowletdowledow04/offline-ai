package com.offlineai.assistant.engine

import com.offlineai.assistant.data.model.ToolAction

/**
 * Advanced Turkmen NLP Engine.
 * Understands phonetic variations, colloquial phrases, suffixes, and intent extraction
 * even if speech recognition makes minor spelling errors.
 */
object TurkmenNlpEngine {

    fun processTurkmenCommand(input: String): ToolAction {
        val normalized = normalizeTurkmenText(input)

        // 1. ÇYRA / FONARIK / YŞYK
        if (containsAny(normalized, "cyra", "fonar", "ysyk", "yagtylyk")) {
            val isTurnOff = containsAny(normalized, "ocur", "sondur", "yap", "stop", "off")
            val isTurnOn = containsAny(normalized, "yak", "ac", "yandyr", "baslat", "on", "gos")

            if (isTurnOff) {
                return ToolAction(
                    thought = "Ulanyjy çyrany öçürmegi buýurdy",
                    action = "toggle_flashlight",
                    parameters = mapOf("enabled" to false),
                    response = "Bolýar, çyrany öçürdim!"
                )
            } else if (isTurnOn || !isTurnOff) {
                return ToolAction(
                    thought = "Ulanyjy çyrany ýakmagy buýurdy",
                    action = "toggle_flashlight",
                    parameters = mapOf("enabled" to true),
                    response = "Bolýar, çyrany ýakdym!"
                )
            }
        }

        // 2. ENJAM ÝAGDAÝY / BATAREÝA / ZARÝAD / WI-FI / ÝAT
        if (containsAny(normalized, "zaryad", "zaryat", "batareya", "tok")) {
            return ToolAction(
                thought = "Batareýa zarýad derejesi soralýar",
                action = "get_system_info",
                parameters = mapOf("query" to "battery"),
                response = "Batareýaňyz barlanýar..."
            )
        }

        if (containsAny(normalized, "wifi", "wi-fi", "internet", "tor")) {
            return ToolAction(
                thought = "Wi-Fi we tor ýagdaýy soralýar",
                action = "get_system_info",
                parameters = mapOf("query" to "wifi"),
                response = "Wi-Fi baglanyşygy barlanýar..."
            )
        }

        if (containsAny(normalized, "pamyat", "bos yat", "yat", "gowrum")) {
            return ToolAction(
                thought = "Telefonyň boş ýat göwrümi soralýar",
                action = "get_system_info",
                parameters = mapOf("query" to "storage"),
                response = "Ýat ýagdaýy barlanýar..."
            )
        }

        if (containsAny(normalized, "yagday", "enjam yagdayy", "status")) {
            return ToolAction(
                thought = "Telefonyň umumy ýagdaýy soralýar",
                action = "get_system_info",
                parameters = mapOf("query" to "all"),
                response = "Telefonyň ýagdaýy barlanýar..."
            )
        }

        // 3. SES DEREJESI (VOLUME)
        if (containsAny(normalized, "ses", "sesi", "volume", "sesini")) {
            // Check for explicit percent
            val percentMatch = Regex("""(\d{1,3})\s*(?:goterim|%|prosent)?""").find(input)
            val level = percentMatch?.groupValues?.get(1)?.toIntOrNull()

            when {
                containsAny(normalized, "doly ac", "in yokary", "in uly", "100") -> {
                    return ToolAction(
                        thought = "Sesi 100% etmek",
                        action = "set_volume",
                        parameters = mapOf("level" to 100, "stream" to "music"),
                        response = "Telefonyň sesi doly (100%) açyldy."
                    )
                }
                containsAny(normalized, "ocur", "yap", "dymdyr", "0") -> {
                    return ToolAction(
                        thought = "Sesi ýapmak / dymdyrmak",
                        action = "set_volume",
                        parameters = mapOf("level" to 0, "stream" to "music"),
                        response = "Telefonyň sesi öçürildi."
                    )
                }
                containsAny(normalized, "peselt", "azalt") -> {
                    return ToolAction(
                        thought = "Sesi peseltmek",
                        action = "set_volume",
                        parameters = mapOf("level" to 30, "stream" to "music"),
                        response = "Ses derejesi peseldildi (30%)."
                    )
                }
                containsAny(normalized, "kopelt", "artdyr", "galdyr") -> {
                    return ToolAction(
                        thought = "Sesi köpeltmek",
                        action = "set_volume",
                        parameters = mapOf("level" to 80, "stream" to "music"),
                        response = "Ses derejesi artdyryldy (80%)."
                    )
                }
                level != null -> {
                    val clamped = level.coerceIn(0, 100)
                    return ToolAction(
                        thought = "Sesi $clamped% etmek",
                        action = "set_volume",
                        parameters = mapOf("level" to clamped, "stream" to "music"),
                        response = "Telefonyň sesi $clamped% sazlandy."
                    )
                }
            }
        }

        // 4. PROGRAMMA AÇMAK (LAUNCH APP)
        val appKeywords = listOf(
            "youtube" to "youtube",
            "yutub" to "youtube",
            "telegram" to "telegram",
            "imo" to "imo",
            "tiktok" to "tiktok",
            "tik tok" to "tiktok",
            "instagram" to "instagram",
            "whatsapp" to "whatsapp",
            "watsap" to "whatsapp",
            "kamera" to "kamera",
            "foto" to "kamera",
            "surat" to "kamera",
            "sazlama" to "settings",
            "settings" to "settings",
            "galereya" to "gallery",
            "kalkulyator" to "calculator",
            "hasaplayjy" to "calculator"
        )

        for ((alias, targetApp) in appKeywords) {
            if (normalized.contains(alias)) {
                return ToolAction(
                    thought = "$targetApp programmasyny açmak buýrugy",
                    action = "launch_app",
                    parameters = mapOf("app_name" to targetApp),
                    response = "$alias programmasy açylýar..."
                )
            }
        }

        if (containsAny(normalized, "ac", "baslat", "gir", "open")) {
            val cleanedName = normalized
                .replace("programmasyny", "")
                .replace("programmasy", "")
                .replace("programma", "")
                .replace("ac", "")
                .replace("open", "")
                .replace("baslat", "")
                .trim()
            if (cleanedName.isNotBlank() && cleanedName.length > 2) {
                return ToolAction(
                    thought = "$cleanedName programmasy açylmaly",
                    action = "launch_app",
                    parameters = mapOf("app_name" to cleanedName),
                    response = "$cleanedName programmasy açylýar..."
                )
            }
        }

        // 5. BUDILNIK / WAGT / OÝARYJY
        if (containsAny(normalized, "budilnik", "alarm", "oyar", "sagat")) {
            val timeMatch = Regex("""(\d{1,2}):(\d{2})""").find(input)
            val hourOnlyMatch = Regex("""(\d{1,2})\s*(?:-da|-de|-e|-a)""").find(input)

            var hour = 7
            var minute = 0

            if (timeMatch != null) {
                hour = timeMatch.groupValues[1].toIntOrNull() ?: 7
                minute = timeMatch.groupValues[2].toIntOrNull() ?: 0
            } else if (hourOnlyMatch != null) {
                hour = hourOnlyMatch.groupValues[1].toIntOrNull() ?: 7
            } else if (containsAny(normalized, "sekiz", "8")) {
                hour = 8
            } else if (containsAny(normalized, "dokuz", "9")) {
                hour = 9
            } else if (containsAny(normalized, "on", "10")) {
                hour = 10
            }

            return ToolAction(
                thought = "Budilnik $hour:${String.format("%02d", minute)} wagtyna gurulmaly",
                action = "set_alarm",
                parameters = mapOf("hour" to hour, "minute" to minute, "message" to "Oýanmak"),
                response = "Budilnik sagat $hour:${String.format("%02d", minute)} wagtyna guruldy!"
            )
        }

        // 6. JAŇ ETMEK (MAKE CALL)
        if (containsAny(normalized, "jan et", "jan ayla", "ayla", "call", "habarlas")) {
            val phoneRegex = Regex("""(\+?\d{8,15})""")
            val phone = phoneRegex.find(input)?.value ?: "+99365000000"

            return ToolAction(
                thought = "$phone belgisine jaň edilmeli",
                action = "make_call",
                parameters = mapOf("phone_number" to phone),
                response = "$phone belgisine jaň edilýär..."
            )
        }

        // 7. SMS UGRATMAK (SEND SMS)
        if (containsAny(normalized, "sms", "hat ugrat", "hat yaz", "sms ugrat")) {
            val phoneRegex = Regex("""(\+?\d{8,15})""")
            val phone = phoneRegex.find(input)?.value ?: ""

            return ToolAction(
                thought = "SMS haty taýýarlanmaly",
                action = "send_sms",
                parameters = mapOf("phone_number" to phone, "message" to input),
                response = "SMS haty ugratmaga taýýarlanyldy."
            )
        }

        // 8. SALAMLAŞYK WE TEBIGY GÜRRÜŇDEŞLIK
        if (containsAny(normalized, "salam", "salowmaleykim", "ertiriniz", "agsamynyz", "hello", "hi")) {
            return ToolAction(
                thought = "Salamlaşyk jogaby",
                action = "none",
                parameters = emptyMap(),
                response = "Salam! Telefonyňyzdaky ähli işleri offline dolandyrmaga taýyn. Näme kömek edip bilerin?"
            )
        }

        if (containsAny(normalized, "sen kim", "adyn name", "ozun hakda", "who are you")) {
            return ToolAction(
                thought = "Asistantyň özüni tanyşdyrmagy",
                action = "none",
                parameters = emptyMap(),
                response = "Men Android üçin internetsiz (offline) işleýän emeli aň kömekçiňiz. Çyrany ýakyp-öçürip, programma açyp, gapdal ses düwmeleri arkaly dolandyrylyp bilýärin."
            )
        }

        if (containsAny(normalized, "nahili", "yagdaylar", "gowumy", "essalawmaleykim")) {
            return ToolAction(
                thought = "Hal-ahwal jogaby",
                action = "none",
                parameters = emptyMap(),
                response = "Gaty gowy, sag boluň! Offline rejimde buýruklaryňyza garaşýaryn."
            )
        }

        if (containsAny(normalized, "sag bol", "spasibo", "thanks")) {
            return ToolAction(
                thought = "Minnetdarlyk jogaby",
                action = "none",
                parameters = emptyMap(),
                response = "Baş üstüne! Başga-da buýrugyňyz barmy?"
            )
        }

        // Fallback natural answer
        return ToolAction(
            thought = "Umumy jogap",
            action = "none",
            parameters = emptyMap(),
            response = "Buýrugyňyza düşündim: '$input'. Çyrany ýakmak, programma açmak, jaň etmek ýa-da batareýa barlamak üçin aýdyp bilersiňiz."
        )
    }

    /**
     * Replaces accented/special characters with basic ASCII equivalents
     * to make matching resilient against speech recognition and keyboard differences.
     */
    private fun normalizeTurkmenText(text: String): String {
        return text.lowercase()
            .replace('ç', 'c')
            .replace('ş', 's')
            .replace('ž', 'z')
            .replace('ň', 'n')
            .replace('ä', 'a')
            .replace('ö', 'o')
            .replace('ü', 'u')
            .replace('ý', 'y')
            .replace(Regex("""[.,/#!$%\^&\*;:{}=\-_`~()?]"""), " ")
            .replace(Regex("""\s+"""), " ")
            .trim()
    }

    private fun containsAny(text: String, vararg keywords: String): Boolean {
        return keywords.any { text.contains(it) }
    }
}
