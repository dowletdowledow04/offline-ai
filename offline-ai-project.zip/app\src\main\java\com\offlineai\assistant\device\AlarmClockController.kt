package com.offlineai.assistant.device

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import com.offlineai.assistant.data.model.ActionResult

class AlarmClockController(private val context: Context) : DeviceController {

    override val actionName: String = "set_alarm"

    override suspend fun execute(parameters: Map<String, Any?>): ActionResult {
        val hour = when (val h = parameters["hour"]) {
            is Number -> h.toInt()
            is String -> h.toIntOrNull() ?: 8
            else -> 8
        }.coerceIn(0, 23)

        val minute = when (val m = parameters["minute"]) {
            is Number -> m.toInt()
            is String -> m.toIntOrNull() ?: 0
            else -> 0
        }.coerceIn(0, 59)

        val message = parameters["message"]?.toString() ?: "AI Kömekçi Budilnik"

        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)

            val formattedTime = String.format("%02d:%02d", hour, minute)
            ActionResult(
                success = true,
                message = "Budilnik $formattedTime wagtyna guruldy",
                data = mapOf("time" to formattedTime, "message" to message)
            )
        } catch (e: Exception) {
            ActionResult(false, "Budilnik gurmakda säwlik: ${e.localizedMessage}")
        }
    }
}
