# ProGuard rules for Offline AI Assistant
-keep class com.google.mediapipe.tasks.genai.** { *; }
-keep class com.offlineai.assistant.data.model.** { *; }
