package com.offlineai.assistant.router

import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.offlineai.assistant.data.model.ToolAction

/**
 * Robust parser that extracts structured ToolAction from LLM output.
 * Handles markdown code fences, embedded JSON, and plain text fallbacks.
 */
class ToolCallParser(private val gson: Gson = Gson()) {

    fun parse(rawOutput: String): ToolAction {
        val trimmed = rawOutput.trim()

        // 1. Try extracting JSON from markdown code fence ```json ... ```
        val jsonCandidate = extractJsonCandidate(trimmed)

        return try {
            val parsed = gson.fromJson(jsonCandidate, ToolAction::class.java)
            if (parsed != null && (parsed.action.isNotBlank() || parsed.response.isNotBlank())) {
                parsed
            } else {
                fallbackPlainResponse(trimmed)
            }
        } catch (e: Exception) {
            // Fallback: If model responded with plain text instead of JSON
            fallbackPlainResponse(trimmed)
        }
    }

    private fun extractJsonCandidate(input: String): String {
        // Check for markdown code blocks
        val codeFenceRegex = Regex("```(?:json)?\\s*([\\s\\S]*?)\\s*```", RegexOption.IGNORE_CASE)
        val match = codeFenceRegex.find(input)
        if (match != null) {
            return match.groupValues[1].trim()
        }

        // Find outermost matching curly braces '{' ... '}'
        val firstBrace = input.indexOf('{')
        val lastBrace = input.lastIndexOf('}')
        if (firstBrace != -1 && lastBrace != -1 && lastBrace > firstBrace) {
            return input.substring(firstBrace, lastBrace + 1).trim()
        }

        return input
    }

    private fun fallbackPlainResponse(rawText: String): ToolAction {
        return ToolAction(
            thought = "Model gönümel jogap berdi",
            action = "none",
            parameters = emptyMap(),
            response = rawText
        )
    }
}
