package com.offlineai.assistant.data.model

import com.google.gson.annotations.SerializedName

/**
 * Represents a structured tool/function call emitted by the LLM.
 */
data class ToolAction(
    @SerializedName("thought")
    val thought: String? = null,

    @SerializedName("action")
    val action: String = "none",

    @SerializedName("parameters")
    val parameters: Map<String, Any?> = emptyMap(),

    @SerializedName("response")
    val response: String = "",

    // Execution state
    var executionStatus: ExecutionStatus = ExecutionStatus.PENDING,
    var executionResult: String? = null
)

enum class ExecutionStatus {
    PENDING,
    EXECUTING,
    SUCCESS,
    FAILED,
    SKIPPED
}

data class ActionResult(
    val success: Boolean,
    val message: String,
    val data: Any? = null
)
