package com.offlineai.assistant.device

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import com.offlineai.assistant.data.model.ActionResult
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class SystemInfoController(private val context: Context) : DeviceController {

    override val actionName: String = "get_system_info"

    override suspend fun execute(parameters: Map<String, Any?>): ActionResult {
        val query = parameters["query"]?.toString()?.lowercase() ?: "all"

        val batteryInfo = getBatteryStatus()
        val wifiInfo = getWifiStatus()
        val storageInfo = getAvailableStorage()
        val currentTime = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()).format(Date())

        val report = when (query) {
            "battery" -> "Batareýa: $batteryInfo"
            "wifi" -> "Wi-Fi: $wifiInfo"
            "storage" -> "Ýat: $storageInfo"
            else -> "Batareýa: $batteryInfo\nWi-Fi: $wifiInfo\nBoş ýat: $storageInfo\nWagt: $currentTime"
        }

        return ActionResult(
            success = true,
            message = report,
            data = mapOf(
                "battery" to batteryInfo,
                "wifi" to wifiInfo,
                "storage" to storageInfo,
                "time" to currentTime
            )
        )
    }

    private fun getBatteryStatus(): String {
        val intentFilter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        val batteryStatus = context.registerReceiver(null, intentFilter) ?: return "Maglumat alnyp bilinmedi"

        val level = batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        val batteryPct = if (level != -1 && scale != -1) (level * 100 / scale.toFloat()).toInt() else 0

        val status = batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL

        return "$batteryPct% (${if (isCharging) "Zarýad alýar" else "Zarýad alanok"})"
    }

    private fun getWifiStatus(): String {
        val connectivityManager = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return "Nämälim"

        val network = connectivityManager.activeNetwork ?: return "Baglanmadyk (Offline)"
        val capabilities = connectivityManager.getNetworkCapabilities(network) ?: return "Baglanmadyk (Offline)"

        return if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            "Wi-Fi baglanan"
        } else if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) {
            "Mobil internet baglanan"
        } else {
            "Baglanmadyk (Offline)"
        }
    }

    private fun getAvailableStorage(): String {
        val stat = StatFs(Environment.getDataDirectory().path)
        val bytesAvailable = stat.blockSizeLong * stat.availableBlocksLong
        val gigabytesAvailable = bytesAvailable / (1024 * 1024 * 1024)
        return "$gigabytesAvailable GB boş"
    }
}
