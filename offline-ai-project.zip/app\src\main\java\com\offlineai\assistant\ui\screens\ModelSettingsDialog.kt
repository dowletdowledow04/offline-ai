package com.offlineai.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.offlineai.assistant.ui.theme.CardDark
import com.offlineai.assistant.ui.theme.PrimaryCyan
import com.offlineai.assistant.ui.theme.TextPrimary
import com.offlineai.assistant.ui.theme.TextSecondary

@Composable
fun ModelSettingsDialog(
    activeEngineName: String,
    onDismiss: () -> Unit,
    onSelectMediaPipeModel: (String) -> Unit,
    onSelectSmartEngine: () -> Unit
) {
    var modelPathInput by remember { mutableStateOf("/data/local/tmp/gemma-2b-it-gpu.task") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardDark,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = null,
                    tint = PrimaryCyan
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text("Offline Model Sazlamalary", color = TextPrimary, fontSize = 18.sp)
            }
        },
        text = {
            Column {
                Text(
                    text = "Häzirki işjeň motor:",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
                Text(
                    text = activeEngineName,
                    color = PrimaryCyan,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "Gemma 2B / Gemini Nano (.task faýly):",
                    color = TextSecondary,
                    fontSize = 13.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = modelPathInput,
                    onValueChange = { modelPathInput = it },
                    label = { Text("Model faýl ýoly (Path)", fontSize = 12.sp) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = PrimaryCyan,
                        unfocusedBorderColor = Color.Gray
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(12.dp))

                Button(
                    onClick = {
                        onSelectMediaPipeModel(modelPathInput)
                        onDismiss()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.Memory, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("MediaPipe Modeli Ýükle", color = Color.Black, fontWeight = FontWeight.SemiBold)
                }

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedButton(
                    onClick = {
                        onSelectSmartEngine()
                        onDismiss()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Smart Engine (Test / Fallback) Saýla", color = PrimaryCyan)
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("Ýap", color = PrimaryCyan)
            }
        }
    )
}
